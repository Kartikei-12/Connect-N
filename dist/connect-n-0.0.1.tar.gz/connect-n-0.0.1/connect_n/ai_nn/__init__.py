"""init file for Recurrent Neural Network based AI agent, package."""

from .preprocess import Preprocess
from .generate_data import GenerateData
